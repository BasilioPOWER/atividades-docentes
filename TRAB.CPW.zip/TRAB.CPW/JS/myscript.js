var mesas = [0,1,2];

mesas[0] = ["Alfamob Sigma","Diretor","1,6 x 0,7 x 0,74","370,00"]
mesas[1] = ["Alfa Painel S40M136","Diretor","0,74 x 1,35 x 0,6","360,00"]
mesas[2] = ["Alfamob Corporativo","Reunião","0,74 x 1,35 x 0,6","500,00"]

function abrirpeça(tipo) {
	var Jan = open("","","width=350px,height=390px","");
with(Jan.document) {
write("<html><head><title>Touro Sentado</title>")
write("<link rel='stylesheet' type='text/css'")
write("href='../css/style1.css'></head><body>")
write("<div class='apres'><h2>" + mesas[tipo][0] + "</h2>")
write("<img width='70%' src='../imagens/" + mesas[tipo][0] + ".jpg' /></div>")
write("<p>Tipo: " + mesas[tipo][1]+"</p>")
write("<p>Dimensões: " + mesas[tipo][2]+ "<p/>")
write("<p>Preço: R$" + mesas[tipo][3])
write("")
write("")
write("<div class='apres'><input type='button' value='Fechar' onClick='window.close();'/></div>")
write("")
write("</body></html>")
close()
}

}



































