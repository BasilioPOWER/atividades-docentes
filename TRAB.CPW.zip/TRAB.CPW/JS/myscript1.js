var cadeiras = [
["Veneza","SecretariaFixaVeneza658Couro","190"],
["Turim","SecretariaGiratoriaTurimCouro","300"],
["Matriz","SecretariaGiratoriaMatrizExport","200"],
["Firenze","PresidenteFirenze560CouroEcologico","620"],
["Ipanema","PresidenteIpanemaPrimeCouro","800"]
];
function mostracadeira(tipo) {
	var nome = document.getElementById("NOMEmesa");
	var foto = document.getElementById("FOTOmesa");
	var preco = document.getElementById("PRECOmesa");

	nome.innerHTML = cadeiras[tipo][0];
	foto.src = "../imagens/"+ cadeiras[tipo][1] +".jpg";
	preco.innerHTML = "R$ " + cadeiras[tipo][2] + ",00";
	
}