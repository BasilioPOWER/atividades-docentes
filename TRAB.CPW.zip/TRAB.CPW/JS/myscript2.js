function validacaoEmail(field) {
usuario = field.value.substring(0, field.value.indexOf("@"));
dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
campo = field.value;




if (campo.search("@")==-1) {alert("Email tem que ter um caractere '@'!")}
	else if (dominio.search(".")==-1) {alert("Email tem que ter pelomenos um caractere '.' após @!")} 
		 else if ((dominio.indexOf(".") ==0)) {alert("O '.' não pode estar imediatamente após o '@' nem no fim do email!")} 
			else if (dominio.lastIndexOf(".") < dominio.length - 1) {} 
				else {alert("O '.' não pode estar imediatamente após o '@' nem no fim do email!")}}

