var tipos = ["Diretor","Reunião"];

var mesas = [0,1,2];
mesas[0] = ["0","Alfamob Sigma","370"];
mesas[1] = ["0","Alfa Painel S40M136","360"];
mesas[2] = ["1","Alfamob Corporativo","500"];


var tipos2 = ["secretária","presidente"];

var cadeiras = [0,1,2,3,4];
cadeiras [0] = ["0","Veneza 658 Fixa Couro","190"];
cadeiras [1] = ["0","Turim Gir. Couro","300"];
cadeiras [2] = ["0","Matriz Exp. Gir. Tecido","200"];
cadeiras [3] = ["1","Firenze 560 Couro ","620"];
cadeiras [4] = ["1","Ipanema Prime Couro ","800"];

function selecionar(f) {
	var ms = f.LstMesas.selectedIndex - 1;
	var cs = f.LstCadeiras.selectedIndex -1;
	var valor = f.TxtValor.value

if (valor.search("R") != -1) {valor = f.TxtValor.value.substring(3);}
        else {valor = f.TxtValor.value }

if (ms != -1) {
			f.LstSelecionados.value += "Mesa " +mesas[ms][1] + "\n";
		valor = Number(valor) + Number(mesas[ms][2])
	} ;
if (cs != -1) {f.LstSelecionados.value += "Cadeira " +cadeiras[cs][1] + "\n";
	valor = Number(valor) + Number(cadeiras[cs][2])
	};

	f.TxtValor.value = ("R$ " + valor)
	

		
	
f.LstMesas.selectedIndex = 0
f.LstCadeiras.selectedIndex = 0

};